import java.util.List;

public class Car {

	private Street[] path;
	
	
	
	public Car(Street[] array) {
		this.path = array;
	}
}
